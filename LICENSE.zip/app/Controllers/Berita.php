<?php

namespace App\Controllers;

use App\Models\KontakModel;
use App\Models\BeritaModel;

class Berita extends BaseController
{
    public function index($index)
    {
        $kontakData = new KontakModel();
        $beritaModel = new BeritaModel();
        $data['kontak'] = $kontakData->first();
        $data['berita'] = $beritaModel->getData();
        $data['index'] = $index;
        $data['title'] = 'Berita';

        return view('berita', $data);
    }

    public function admin_berita($index)
    {
        $beritaModel = new BeritaModel();
        $data['berita'] = $beritaModel->getData();
        $data['index'] = $index;
        $data['title'] = 'Berita';

        return view('admin/berita/index.php', $data);
    }

    public function tambah_berita()
    {
        $data['title'] = 'Tambah Berita';

        return view('admin/berita/tambah_berita.php', $data);
    }

    public function add_berita()
    {
        if (!$this->validate([
            'thumbnail' => [
                'rules' => 'uploaded[thumbnail]|mime_in[thumbnail,image/jpg,image/jpeg,image/gif,image/png]|max_size[thumbnail,5120]',
                'errors' => [
                    'uploaded' => 'Harus Ada File yang diupload',
                    'mime_in' => 'File Extention Harus Berupa jpg,jpeg,gif,png',
                    'max_size' => 'Ukuran File Maksimal 3 MB'
                ]

            ]
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }

        $berita = new BeritaModel();
        $dataFoto = $this->request->getFile('thumbnail');
        $fileName = $dataFoto->getRandomName();

        $berita->insert([
            'judul' => $this->request->getPost('judul'),
            'thumbnail' => $fileName,
            'isi' => $this->request->getPost('isi'),
            'tgl_dibuat' => date("Y-m-d"),
            'tgl_diupdate' => date("Y-m-d")
        ]);

        $dataFoto->move('upload/image/berita/', $fileName);
        session()->setFlashdata('success', 'Berhasil menambah data berita');
        return redirect()->to(base_url('admin/berita/1'));
    }

    public function uploadGambar()
    {
        $security = \Config\Services::security();
        helper('security');
        helper('html');
        helper('form');
        helper('url');
        helper('text');

        if ($this->request->getFile('file')) {
            $dataFile = $this->request->getFile('file');
            $fileName = $dataFile->getRandomName();
            $dataFile->move('upload/image/berita/', $fileName);
            echo base_url("upload/image/berita/$fileName");
        }
    }

    public function edit_berita($id)
    {
        $beritaData = new BeritaModel();
        $data['berita'] = (object) $beritaData->where('id_berita', $id)->first();
        $data['title'] = 'Edit Berita';

        return view('admin/berita/edit_berita.php', $data);
    }
}
