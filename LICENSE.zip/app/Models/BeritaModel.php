<?php

namespace App\Models;

use CodeIgniter\Model;

class BeritaModel extends Model
{
    protected $table = "berita";
    protected $primaryKey = "id_berita";
    protected $returnType = "object";
    protected $useTimestamps = false;
    protected $allowedFields = ['judul', 'thumbnail', 'isi', 'tgl_dibuat', 'tgl_diupdate'];

    public function getData()
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('berita')->orderBy("tgl_dibuat", "desc");
        $query = $builder->get();
        return $query->getResult();
    }

    public function deleteData()
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('berita');
        $builder->emptyTable();
    }
}
